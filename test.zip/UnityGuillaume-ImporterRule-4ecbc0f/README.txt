Allow to define custom import rules for texture & model define on name.

Step to use :
- Copy ImportManager folder inside your project
- In the Asset > Create menu (or right click in project) you have a new Importer/Config asset. Create one (recommended on a folder of its own as it will create a folder for its config)
- Add a rule, then you can define parameters for the given name filter (e.g if you enter _Normal, all file that contain _Normal in the name will use those settings)
